<?php get_header() ?>

<div class="card mb-3">
    <img src="https://images.unsplash.com/photo-1713962488123-80b6b07a7c64?q=80&w=1171&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
        class="card-img-top" alt="...">
    <div class="card-body">
        <h5 class="card-title">About us</h5>
        <p class="card-text">Benvenuti nel nostro mondo! Siamo un team appassionato di innovazione, creatività e
            soluzioni su misura. La nostra missione è fornire esperienze straordinarie attraverso il design, lo sviluppo
            e la consulenza. Con una combinazione unica di talento e dedizione, ci impegniamo a superare le aspettative
            dei nostri clienti. Scoprite di più su di noi e sul nostro lavoro esplorando il nostro sito. Siamo qui per
            trasformare le vostre idee in realtà!</p>
    </div>
</div>

<?php get_footer() ?>