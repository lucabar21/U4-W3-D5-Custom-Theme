<?php if (have_posts()):
    while (have_posts()):
        the_post(); ?>

        <a href="<?php the_permalink(); ?>">
            <div class="card mb-3">
                <img src="<?= get_the_post_thumbnail_url() ?: wp_get_attachment_url(68); ?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title"><?php the_title(); ?></h5>
                    <p class="card-text"><?php the_content(); ?></p>
                </div>
            </div>
        </a>
    <?php endwhile; ?>

    <?php
    if (get_next_posts_link()) {
        next_posts_link();
    }
    ?>
    <?php
    if (get_previous_posts_link()) {
        previous_posts_link();
    }
    ?>

<?php else: ?>

    <p>No posts found. :(</p>

<?php endif; ?>