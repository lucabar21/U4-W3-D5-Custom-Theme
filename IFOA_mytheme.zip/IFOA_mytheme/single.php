<?php

get_header();
the_post(); ?>
<div class="card mb-3">
    <img src="<?= get_the_post_thumbnail_url() ?: wp_get_attachment_url(68); ?>" class="card-img-top" alt="...">
    <div class="card-body">
        <h5 class="card-title"><?php the_title(); ?></h5>
        <p class="card-text"><?php the_content(); ?></p>
        <div class="card-text text-center"><button type="button" class="btn btn-warning"><?php wp_link_pages(); ?>
                <?php edit_post_link(); ?></button></div>
    </div>
</div>

<?php
get_footer();